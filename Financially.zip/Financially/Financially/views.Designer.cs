﻿namespace Test_3
{
    partial class views
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.titlebar = new System.Windows.Forms.PictureBox();
            this.moveform = new System.Windows.Forms.Timer(this.components);
            this.back = new System.Windows.Forms.Button();
            this.spendingDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.spendingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.financially_usersDataSet = new Test_3.financially_usersDataSet();
            this.spendingTableAdapter = new Test_3.financially_usersDataSetTableAdapters.spendingTableAdapter();
            this.tableAdapterManager = new Test_3.financially_usersDataSetTableAdapters.TableAdapterManager();
            this.datesort = new System.Windows.Forms.Button();
            this.typesort = new System.Windows.Forms.Button();
            this.selecttype = new System.Windows.Forms.ComboBox();
            this.datepicker = new System.Windows.Forms.DateTimePicker();
            this.datepicker2 = new System.Windows.Forms.DateTimePicker();
            this.total = new System.Windows.Forms.Label();
            this.reset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.titlebar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spendingDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spendingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.financially_usersDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // titlebar
            // 
            this.titlebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(141)))), ((int)(((byte)(155)))));
            this.titlebar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titlebar.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlebar.Location = new System.Drawing.Point(0, 0);
            this.titlebar.Name = "titlebar";
            this.titlebar.Size = new System.Drawing.Size(518, 30);
            this.titlebar.TabIndex = 15;
            this.titlebar.TabStop = false;
            this.titlebar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.titlebar_MouseDown);
            this.titlebar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.titlebar_MouseUp);
            // 
            // moveform
            // 
            this.moveform.Interval = 1;
            this.moveform.Tick += new System.EventHandler(this.moveform_Tick);
            // 
            // back
            // 
            this.back.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(141)))), ((int)(((byte)(155)))));
            this.back.FlatAppearance.BorderSize = 0;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.back.ForeColor = System.Drawing.Color.White;
            this.back.Location = new System.Drawing.Point(12, 389);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(110, 30);
            this.back.TabIndex = 16;
            this.back.Text = "back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // spendingDataGridView
            // 
            this.spendingDataGridView.AutoGenerateColumns = false;
            this.spendingDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.spendingDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.spendingDataGridView.DataSource = this.spendingBindingSource;
            this.spendingDataGridView.Location = new System.Drawing.Point(7, 36);
            this.spendingDataGridView.Name = "spendingDataGridView";
            this.spendingDataGridView.ReadOnly = true;
            this.spendingDataGridView.Size = new System.Drawing.Size(343, 342);
            this.spendingDataGridView.TabIndex = 17;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "date";
            this.dataGridViewTextBoxColumn2.HeaderText = "date";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "type";
            this.dataGridViewTextBoxColumn3.HeaderText = "type";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "price";
            this.dataGridViewTextBoxColumn4.HeaderText = "price";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // spendingBindingSource
            // 
            this.spendingBindingSource.DataMember = "spending";
            this.spendingBindingSource.DataSource = this.financially_usersDataSet;
            // 
            // financially_usersDataSet
            // 
            this.financially_usersDataSet.DataSetName = "financially_usersDataSet";
            this.financially_usersDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // spendingTableAdapter
            // 
            this.spendingTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.spendingTableAdapter = this.spendingTableAdapter;
            this.tableAdapterManager.UpdateOrder = Test_3.financially_usersDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.user_credsTableAdapter = null;
            // 
            // datesort
            // 
            this.datesort.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datesort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(141)))), ((int)(((byte)(155)))));
            this.datesort.FlatAppearance.BorderSize = 0;
            this.datesort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.datesort.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.datesort.ForeColor = System.Drawing.Color.White;
            this.datesort.Location = new System.Drawing.Point(376, 194);
            this.datesort.Name = "datesort";
            this.datesort.Size = new System.Drawing.Size(121, 56);
            this.datesort.TabIndex = 18;
            this.datesort.Text = "Sort by date";
            this.datesort.UseVisualStyleBackColor = false;
            this.datesort.Click += new System.EventHandler(this.datesort_Click);
            // 
            // typesort
            // 
            this.typesort.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.typesort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(141)))), ((int)(((byte)(155)))));
            this.typesort.FlatAppearance.BorderSize = 0;
            this.typesort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.typesort.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.typesort.ForeColor = System.Drawing.Color.White;
            this.typesort.Location = new System.Drawing.Point(376, 72);
            this.typesort.Name = "typesort";
            this.typesort.Size = new System.Drawing.Size(121, 56);
            this.typesort.TabIndex = 20;
            this.typesort.Text = "Sort by type";
            this.typesort.UseVisualStyleBackColor = false;
            this.typesort.Click += new System.EventHandler(this.typesort_Click);
            // 
            // selecttype
            // 
            this.selecttype.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(141)))), ((int)(((byte)(155)))));
            this.selecttype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selecttype.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.selecttype.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.selecttype.ForeColor = System.Drawing.Color.White;
            this.selecttype.FormattingEnabled = true;
            this.selecttype.Items.AddRange(new object[] {
            "water",
            "electricity",
            "shopping",
            "internet",
            "phone",
            "taxes",
            "clothing",
            "restaurants",
            "other"});
            this.selecttype.Location = new System.Drawing.Point(376, 36);
            this.selecttype.Name = "selecttype";
            this.selecttype.Size = new System.Drawing.Size(121, 30);
            this.selecttype.TabIndex = 21;
            // 
            // datepicker
            // 
            this.datepicker.Font = new System.Drawing.Font("Century Gothic", 13.5F);
            this.datepicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datepicker.Location = new System.Drawing.Point(376, 158);
            this.datepicker.Name = "datepicker";
            this.datepicker.Size = new System.Drawing.Size(60, 30);
            this.datepicker.TabIndex = 22;
            // 
            // datepicker2
            // 
            this.datepicker2.Font = new System.Drawing.Font("Century Gothic", 13.5F);
            this.datepicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datepicker2.Location = new System.Drawing.Point(437, 158);
            this.datepicker2.Name = "datepicker2";
            this.datepicker2.Size = new System.Drawing.Size(60, 30);
            this.datepicker2.TabIndex = 23;
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Font = new System.Drawing.Font("Century Gothic", 20F);
            this.total.ForeColor = System.Drawing.SystemColors.Control;
            this.total.Location = new System.Drawing.Point(190, 385);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(78, 33);
            this.total.TabIndex = 25;
            this.total.Text = "Total";
            this.total.Visible = false;
            // 
            // reset
            // 
            this.reset.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(141)))), ((int)(((byte)(155)))));
            this.reset.FlatAppearance.BorderSize = 0;
            this.reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reset.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.reset.ForeColor = System.Drawing.Color.White;
            this.reset.Location = new System.Drawing.Point(375, 280);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(121, 56);
            this.reset.TabIndex = 26;
            this.reset.Text = "Reset";
            this.reset.UseVisualStyleBackColor = false;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // views
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(69)))), ((int)(((byte)(83)))));
            this.ClientSize = new System.Drawing.Size(518, 431);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.total);
            this.Controls.Add(this.datepicker2);
            this.Controls.Add(this.datepicker);
            this.Controls.Add(this.selecttype);
            this.Controls.Add(this.typesort);
            this.Controls.Add(this.datesort);
            this.Controls.Add(this.spendingDataGridView);
            this.Controls.Add(this.back);
            this.Controls.Add(this.titlebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "views";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "views";
            this.Load += new System.EventHandler(this.views_Load);
            ((System.ComponentModel.ISupportInitialize)(this.titlebar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spendingDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spendingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.financially_usersDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox titlebar;
        private System.Windows.Forms.Timer moveform;
        private System.Windows.Forms.Button back;
        private financially_usersDataSet financially_usersDataSet;
        private System.Windows.Forms.BindingSource spendingBindingSource;
        private financially_usersDataSetTableAdapters.spendingTableAdapter spendingTableAdapter;
        private financially_usersDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView spendingDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button datesort;
        private System.Windows.Forms.Button typesort;
        private System.Windows.Forms.ComboBox selecttype;
        private System.Windows.Forms.DateTimePicker datepicker;
        private System.Windows.Forms.DateTimePicker datepicker2;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Button reset;
    }
}