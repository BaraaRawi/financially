﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Test_3
{
    public partial class views : Form
    {
        public views()
        {
            InitializeComponent();
        }

        //-------------------------------------------------Move Form----------------------------------------------------//

        int mousex, formleft, mousey, formtop;   
        private void titlebar_MouseUp(object sender, MouseEventArgs e)
        {
            moveform.Stop();
        }


        private void titlebar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mousex = Cursor.Position.X;
                mousey = Cursor.Position.Y;
                formleft = this.Left;
                formtop = this.Top;
                moveform.Start();
            }
        }

        private void moveform_Tick(object sender, EventArgs e)
        {
            this.Left = formleft - (mousex - Cursor.Position.X);
            this.Top = formtop - (mousey - Cursor.Position.Y);
        }

        //---------------------------------------------Datagridview Load-------------------------------------------------//

        private void spendingBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.spendingBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.financially_usersDataSet);

        }

        private void views_Load(object sender, EventArgs e)
        {
            datepicker.Format = DateTimePickerFormat.Custom;
            datepicker.CustomFormat = "MM";
            datepicker.ShowUpDown = true;
            datepicker2.Format = DateTimePickerFormat.Custom;
            datepicker2.CustomFormat = "yyyy";
            datepicker2.ShowUpDown = true;

            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='D:\Visual Studio\Financially\Financially\financially_users.mdf';Integrated Security=True;Connect Timeout=30");
            SqlCommand cmd = new SqlCommand("SELECT date, type, price FROM spending WHERE user_id='"+Login.user_id+"'", con); 
            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            DataTable tempDT = new DataTable();
            tempDT = dt.DefaultView.ToTable(true, "date","type","price");
            spendingDataGridView.DataSource = tempDT;
            con.Close();
            total.Visible = false;


        }

        private void reset_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='D:\Visual Studio\Financially\Financially\financially_users.mdf';Integrated Security=True;Connect Timeout=30");
            SqlCommand cmd = new SqlCommand("SELECT date, type, price FROM spending WHERE user_id='" + Login.user_id + "'", con);
            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            DataTable tempDT = new DataTable();
            tempDT = dt.DefaultView.ToTable(true, "date", "type", "price");
            spendingDataGridView.DataSource = tempDT;
            con.Close();
            total.Visible = false;
        }

        private void datesort_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='D:\Visual Studio\Financially\Financially\financially_users.mdf';Integrated Security=True;Connect Timeout=30");
            SqlCommand cmd = new SqlCommand("SELECT date, type, price FROM spending WHERE" +
                " user_id='" + Login.user_id + "' AND (DATEPART(MM, date)='"+datepicker.Text+ "') AND (DATEPART(yy, date)='" + datepicker2.Text + "') AND (DATEPART(dd, date) LIKE '%')", con);
            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            DataTable tempDT = new DataTable();
            tempDT = dt.DefaultView.ToTable(true, "date", "type", "price");
            spendingDataGridView.DataSource = tempDT;
            con.Close();

            SqlDataReader reader;
            cmd.CommandText = ("SELECT SUM(price) FROM spending WHERE user_id='" + Login.user_id + "' AND year(date)="+datepicker2.Text+ " AND  month(date)="+datepicker.Text+" GROUP BY month(date)");
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            reader = cmd.ExecuteReader();
            total.Visible = true;
            if (reader.Read())
            { total.Text = "Total: " + reader.GetSqlMoney(0).ToString(); }
            else { total.Text = "Total: Null"; }
        }

  
        private void typesort_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='D:\Visual Studio\Financially\Financially\financially_users.mdf';Integrated Security=True;Connect Timeout=30");
            SqlCommand cmd = new SqlCommand("SELECT date, type, price FROM spending WHERE user_id='" + Login.user_id + "' AND type='"+selecttype.SelectedItem+"';", con);
            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            DataTable tempDT = new DataTable();
            tempDT = dt.DefaultView.ToTable(true, "date", "type", "price");
            spendingDataGridView.DataSource = tempDT;
            con.Close();

            SqlDataReader reader;
            cmd.CommandText = ("SELECT SUM(price) FROM spending WHERE user_id='" + Login.user_id + "' AND type='" + selecttype.SelectedItem + "'");
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();
            total.Visible = true;
            total.Text = "Total: " + reader.GetSqlMoney(0).ToString();
        }



        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
